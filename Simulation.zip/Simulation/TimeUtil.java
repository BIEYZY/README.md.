package simulation;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/*
 * TimeUtil provides formatted timestamps.
 * This allows us to measure delays and ordering
 * of events in the simulation.
 */
public class TimeUtil {

    // Format time as HH:mm:ss.SSS
    private static final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    // Returns the current system time
    public static String now() {
        return LocalTime.now().format(formatter);
    }
}