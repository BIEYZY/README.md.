package simulation;

/*
 * Client represents a distributed process.
 * Each client runs as a separate thread.
 */
public class Client extends Thread {

    private NamingServer naming;
    private ConsistencyModel consistency;

    public Client(String name,
                  NamingServer naming,
                  ConsistencyModel consistency) {

        super(name);
        this.naming = naming;
        this.consistency = consistency;
    }

    /*
     * Simulates a client request lifecycle.
     */
    @Override
    public void run() {

        System.out.println("[" + TimeUtil.now() +
                "] " + getName() + " started");

        simulateDelay(1000); // network delay

        // Resolve resource name
        String target = naming.resolve("file1");

        System.out.println("[" + TimeUtil.now() +
                "] " + getName() +
                " resolved file1 to " + target);

        // Write data using consistency model
        consistency.write(10);
        
        // Read data after write (for client-centric consistency)
if (consistency instanceof ClientCentricConsistency) {
    ClientCentricConsistency cc =
            (ClientCentricConsistency) consistency;

    int value = cc.read();

    System.out.println("[" + TimeUtil.now() + "] "
            + getName() + " read value " + value);
}
    }

    private void simulateDelay(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
        }
    }
}