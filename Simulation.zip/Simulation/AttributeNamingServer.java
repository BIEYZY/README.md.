package simulation;

/*
 * AttributeNamingServer simulates attribute-based naming.
 * This model is flexible but costly.
 */
public class AttributeNamingServer implements NamingServer {

    @Override
    public String resolve(String name) {
        simulateDelay(600); // highest overhead
        return "Replica-1";
    }

    private void simulateDelay(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
        }
    }
}
