
package simulation;

/*
 * ClientCentricConsistency simulates monotonic reads.
 * A client will never observe older data than it has
 * already seen.
 */
public class ClientCentricConsistency implements ConsistencyModel {

    private Replica replica;

    // Each client tracks the last value it observed
    private int lastSeenValue = Integer.MIN_VALUE;

    public ClientCentricConsistency(Replica replica) {
        this.replica = replica;
    }

    /*
     * Write operation updates the replica.
     * Client-centric consistency mainly affects reads,
     * but writes are still allowed.
     */
    @Override
    public synchronized void write(int value) {
        replica.write(value);
        lastSeenValue = value;

        System.out.println("[" + TimeUtil.now() +
                "] Client-centric consistency (write)");
    }

    /*
     * Read operation ensures monotonic reads.
     */
    public synchronized int read() {
        int currentValue = replica.read();

        // Ensure client never sees older data
        if (currentValue < lastSeenValue) {
            return lastSeenValue;
        }

        lastSeenValue = currentValue;
        return currentValue;
    }
}